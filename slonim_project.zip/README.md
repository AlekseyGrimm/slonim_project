# slonim_project
 
